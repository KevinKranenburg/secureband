<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="ie=edge">
	<meta name="author" content="Kevin Kranenburg">
	<link rel="stylesheet" type="text/css" href="style.css?ts=<?=time()?>" />
	<link href="https://fonts.googleapis.com/css?family=Abel&display=swap" rel="stylesheet">
</head>
<body>

<div class="footer2">
  <p>&copy; 2019 | Kevin Kranenburg</p>
</div>

</body>
</html>