# Evaluatie

Het is belangrijk om na het opleveren van een project terug te kijken op het hele proces

* Wat ging er goed
* Waar had je moeite mee
* Haalde je de oplevermomenten in je planning? Waarom wel / niet?
* Hoe ging de communicatie met de betrokkenen
* Wat zou je anders doen

Dit geeft je waardevolle informatie over je eigen werkwijze en competenties.
Het geeft je richting en focus voor een volgend project. Kijk goed nar hoe het is gegaan en wees eerlijk. 



