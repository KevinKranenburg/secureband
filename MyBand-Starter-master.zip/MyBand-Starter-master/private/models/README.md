# Models

Hier zet je alle bestanden met de code die gegevens voor je ophalen uit de database (of van andere plekken)
Per soort data, maak je één bestand, bijvoorbeeld:
- Pagina's  = page.php
- People = people.php
- Agenda -= agenda.php 
- Foto's = photo.php