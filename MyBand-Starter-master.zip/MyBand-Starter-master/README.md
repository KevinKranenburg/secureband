# Car rally's

## Sprint 1
- Planning in doc
- Verslag in doc
- Link: http://25953.hosts2.ma-cloud.nl/bewijzenmap/periode1.3/proj/testcode/


## Sprint 2
- Planning in doc
- Verslag in doc
- Link: http://25953.hosts2.ma-cloud.nl/bewijzenmap/periode1.3/proj/testcode/

## Sprint 3
- Planning in doc
- Verslag in doc
- Link: http://25953.hosts2.ma-cloud.nl/bewijzenmap/periode1.3/proj/testcode/

## Final version
- Link: http://25953.hosts2.ma-cloud.nl/bewijzenmap/periode1.3/proj/testcode/public/index.php
